/*
   Title: exercice_4.c
   Titre: Utilisons l'�cran 16x2 caract�res
			Utilise la librairie XLCD, les commandes printf et sprintf

   Version: 1.0
   Auteur: R.Ziegler
   Date: Janvier 2012

   Description: exercice 4�me soir
	
	Utiliser le PORTD, LATD, TRISD pour mettre ne mouvement les LEDS
	du microdule LED

	Connections LCD
	PORT LCD
	BIT0 RS
	BIT1 RW
	BIT2 E
	BIT3 BL
	BIT4 LCD4 Pressoir	3
	BIT5 LCD5 Pressoir 	4
	BIT6 LCD6 Pressoir  2
	BIT7 LCD7 Pressoir 	1

	nous utiliserons le code microchip modifi�
	

*/
#include <p18f4550.h>   
#include <stdio.h>

#include "..\shared\picstar.h"
#include "..\shared\picstar_delays.h"


// variables globale

volatile u8 vitesse;
#define ON 1
#define OFF 0

#define EXERCICE_4b

// D�but des exercices

// Cet exercice est complet et teste votre affichage
// Comme exercice, vous  pouvez modifier le code pour comptes les impulsions
// sur les boutons et afficher l'�tat du compteur.
// par exemple le bouton du haut et du bas sont des compteurs Y
// et 2 boutons du milieu sont les boutons x.
// pour chaque paire, un bouton incr�mente un compteur, l'autre le d�cr�mente.
#ifdef EXERCICE_4a

#include "..\shared\pwm_util.h"
#include "..\shared\adc_util.h"
#include "..\shared\xlcd_driver.h" 

void main()
{

	char LCD_buffer[32];
	u8 boutons;
	u8 presse;
	u8 compteur=0;

	init_picstar();

    init_lcd();

	set_backlight(ON);

// Boucle principale ......................................................................
	while(1)
	{
// Nous lisons le port D en entr�e pour identifier la position des 4 boutons
	TRISD|=0xf0; // bit du haut en entr�e	
	boutons=PORTD & 0xf0;
	TRISD&=0x0f; // remettre les  lignes en sortie
	
	if(boutons == 0xe0)presse=3;
	else if(boutons == 0xd0)presse=4;
	else if(boutons == 0xb0)presse=2;
	else if(boutons == 0x70)presse=1;
	else presse=0;

	lcd_gotoxy(0,0);
	fprintf(_H_USER,"HELLO WORLD %3u      ", compteur & 0xff);
	lcd_gotoxy(0,1);
	
	fprintf(_H_USER,"boutons = %u",presse);

	compteur++;

	delay_ms(100);
	} // end while
}// fin du programme ---------------------------------------------------------------------
#endif

// int�grer l'exercice 3 dans l'exercice 4, le plus simple est de copier le code 
// de l'exercice 3a et d'y ajouter le code LCD
// afficher la valeur de conversion adc et essayer les divers formats
// d�cimal, hex et binaire

#ifdef EXERCICE_4b

#include "..\shared\pwm_util.h"
#include "..\shared\adc_util.h"
#include "..\shared\xlcd_driver.h" 

void main()
{
	u16 resultat;
	u8 compteur=0;

	init_picstar();

	init_adc(); // code de l'exercice 2

	// initialiser le pwm sur RC2
	init_pwm(); // code a d�velopper

	// initialise l'�cran lcd
    init_lcd();
	set_backlight(ON);
	
	while(1)
	{
	u16 tmp;
	resultat=get_adc0();
	set_pwm(1,resultat); // pwm duty = potentiometre
	lcd_gotoxy(0,0);
	fprintf(_H_USER,"HELLO WORLD       ");
	lcd_gotoxy(0,1);
//	fprintf(_H_USER,"ADC= %u  ",resultat);	 // entier 8 bits
//	fprintf(_H_USER,"ADC= %X  ",resultat);	 // hex simple
//	fprintf(_H_USER,"ADC= %#X  ",resultat);  // hexa avec 0x devant
//	fprintf(_H_USER,"ADC= %-3u  ",resultat); // allign� � gauche
	fprintf(_H_USER,"ADC= %+3u  ",resultat); // allign� � droite
	delay_ms(10);
	} // end while
}// fin of program
#endif


// copier votre r�sultat de l'exercice 3b
// activer le code son en pla�ant un fil entre RC2 et RA4 (connect� au buzzer)
// vous pouvez aussi connecter un Haut Parleur entre z�ro et RC2 mais ca fait plus de bruit !
// afficher le r�sultat de la conversion ADC en premi�re ligne
// 1. calculer la fr�quence et afficher la en 2eme ligne, par exemple en Hz  

// 2. plus difficile, on manipule des chiffres, et du code C
//    afficher la fr�quence en kHz avec 1 d�cimale apr�s la virgule
// 	  ceci sans utiliser de virgule flottante.
//    pour r�ussir cet exercice, on calcule la fr�quence 10x sup�rieur � l'affichage
//    et on affiche 2 chiffres s�par�s d'un point, le 2�me chiffre est le reste d'une division
//    donc fprint "freq= %u.%1u",freq/10,freq%10;

#ifdef EXERCICE_4c

#include "..\shared\pwm_util.h"
#include "..\shared\adc_util.h"
#include "..\shared\xlcd_driver.h" 
				
// calculer la p�riode minimale qui correspond a 16khz
//					freq. horl. / fr�quence limite / pr�-diviseur
	#define PLIMITE 12000000/16000/16 // = 46

void main()
{
	u16 resultat;
	u8 compteur=0;

	init_picstar();

	init_adc(); // code de l'exercise 2

	// initialiser le pwm sur RC2
	init_pwm(); // code a d�velopper

	// initialise l'�cran lcd
    init_lcd();
	set_backlight(ON);
	
	// boucle principale---------------------------------------------
	while(1)
	{
	u16 tmp;

	resultat=255-get_adc0(); // j'inverse le r�sultat pour avoir une frequence
							 // qui grimpe, la p�riode/pot �tant l'inverse
	
	// je limite la fr�quence a 16khz, voir la d�finition de PLIMITE
	if((resultat+=PLIMITE)>255)resultat=255;
	set_freq(1,resultat);    // j'appelle la fonction qui met a jours la p�riode


	lcd_gotoxy(0,0);
	fprintf(_H_USER,"ADC= %u ", resultat);
	lcd_gotoxy(0,1);
	// calcul de la fr�quence en 10kHz donc 10x trop grand pour pouvoir 
	// afficher le r�sultat 1 chiffre apr�s la virgule.
	tmp=120000L/16/resultat;	
	// 120000L pour que le compilateur calcule avec 16 bits, voir ANSI C
	
	// la fr�quence = tmp/10, le chiffre ap�s la virgule modulo 10 (%)
	fprintf(_H_USER,"Freq=%u.%1u kHz ",tmp/10 & 0xff, tmp%10 &0xff);

	delay_ms(10);
	} // end while -------------------------------------------------
}// fin of program
#endif

// fin des exercises
