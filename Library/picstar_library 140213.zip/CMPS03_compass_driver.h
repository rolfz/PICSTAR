/*
   Title: compass cmps03 driver Picstar
   Purpose: allows to read the 2 modes of the electronic compass
   File name: CMPS03_compass_driver.c
   Version: 1.0
   Autor: Rolf Ziegler
   Date: April 2010

   description: This routine will read the compass direction in 1/10 of degree
            and 255/360 degree resolution.
            
            The compass will not give absolute north, but the magnetic
            field situation at the sensor position. This means that the 
            natural earth north is alterated by electric wires, magnets and metal
            located around the sensor position.
            
            http://www.robot-electronics.co.uk/htm/cmps3tech.htm

*/
#ifndef __CMPS03_driver
#define __CMPS03_driver
/* register definition

0   Software Revision Number 
1   Compass Bearing as a byte, i.e. 0-255 for a full circle 
2,3   Compass Bearing as a word, i.e. 0-3599 for a full circle, representing 0-359.9 degrees. 
4,5   Internal Test - Sensor1 difference signal - 16 bit signed word 
6,7   Internal Test - Sensor2 difference signal - 16 bit signed word 
8,9   Internal Test - Calibration value 1 - 16 bit signed word 
10,11   Internal Test - Calibration value 2 - 16 bit signed word 
12   Unused - Read as Zero 
13   Unused - Read as Zero 
14   Unused - Read as Undefined 
15   Calibrate Command - Write 255 to perform calibration step. See t 0 version 
*/

#define SOFT_REV 0
#define COMPASS_BEAR255 1
#define COMPASS_BEAR360 2 //+3
#define COMPASS_CALLIB 15
  
 
void cmps03_init(void)
{
   InitI2C();
}


void cmps03_write_byte(u8 address, u8 data) 
{
	i2c_write_byte(0xc0,address,data);
}


u8 cmps03_read_byte(u8 address) 
{
 
 return(i2c_read_byte(0xc0,address));
}


u16 cmps03_read_compass(u8 address)
{
   return(i2c_read_word(0xc0,address));
}
////////////////////// end of driver file /////////////////////////////////////
#endif
