#ifndef __PICSTARINT
#define __PICSTARINT
/*

  Name: picstar_int.h
  Title: Interrupt handler for picstar robot project


  By: Rolf Ziegler
  Date: May 2010

  Purpose: Manage all interrupt routines of the project
			this including the time scheduler for various routines
			and other interrupt routines
*/

void InterruptHandlerHigh (void);
void StepPfm(s8 pfm1,s8 pfm2);

// we need to keep in mind that we run at 12mips
// so every ms we execute 12000 instructions.

void Robot_Run1ms(void);	// code runs every 1ms
void Robot_Run20ms(void);	// code runs every 20ms
void Robot_Run60msec(void);	// code runs every 100ms
// guest routine
#ifdef ENABLE_RF
void RF12B_ISR(void);
#endif
s8 Speed_M1=0,Speed_M2=0;
volatile u8 cnt20ms=0;
volatile u8 cnt1sec=0;

//----------------------------------------------------------------------------
// High priority interrupt vector

#pragma code InterruptVectorHigh = 0x1008

void 
InterruptVectorHigh(void)
{
  _asm
    goto InterruptHandlerHigh //jump to interrupt routine
  _endasm
}

#pragma code

#pragma interrupt InterruptHandlerHigh
void InterruptHandlerHigh(void)
{
#define OneMS 255-187  // not used yet
#define HalfMS 255-88  // testes gives 998hz

#ifdef ENABLE_RF
	if((INTCONbits.RBIF))// & (!RF_nIRQ)) // nIRG went low
	{
	LedV=LEDON;
	RF12B_ISR();
	INTCONbits.RBIF=0; // clear interrupt bit
	LedV=LEDOFF;
	}
#endif
  if (INTCONbits.TMR0IF)
    {                                   //check for TMR0 overflow
//	LedV=LEDON;
	  TMR0L=HalfMS;  // let's shorten the interrupt time to get 1ms
      INTCONbits.TMR0IF = 0;            //clear interrupt flag
	  Robot_Run1ms();
	 	
 	if(cnt20ms++==40){
						cnt20ms=0;
						Robot_Run20ms();			

						if(cnt1sec++==3){
        					  	cnt1sec=0;
						  		Robot_Run60msec();
		 				  				 } // end 1sec.
					   } // end 20ms
	}
// end TMR0IR
// end interrupt on RB 
//	LedV=LEDOFF;
} // end ISR

void Init_RobotIsr(void)
{
  INTCON = 0x20;                //disable global and enable TMR0 interrupt
  INTCON2 = 0x84;               //TMR0 high priority
  RCONbits.IPEN = 1;            //enable priority levels

// timer0 initialisation
  TMR0H = 0;                    //clear timer
  TMR0L = 0;                    //clear timer

// we want a timer0 interrupt of 1ms
  OpenTimer0( TIMER_INT_ON & T0_8BIT & T0_SOURCE_INT  & T0_PS_1_64 );

// to get 1ms we will need to preset the interrupt counter to 187
	// 64(prescale)*187(timer0 counter)*1/12mhz= .9973ms
// enable interrupt

// we do this in the main routine
//  INTCONbits.GIEH = 1;

// in case we need a debug bit, let's do it on RB7
}
#endif
