/*
   Title:    i2c software driver
   Purpose:  used to drive i2c devices not connected to RB0-RB1
   File name: i2c_sw_driver.h
   Version: 1.0

   by: Rolf Ziegler
   date: April.2010

   description:
      I2C lines have to be pulled up to VCC (on board on PICSTAR) RB0+RB1.
      Driver uses TRIS in and out to set low level on the line.
      Driver is written in order to support clock-stretching
      this allows a slow slave to pull-down the clock if he cannot satify timing.
      
      Some issues have been resolved with the LATB swiching to high level once 
      we where reading the clock status. For this reason some routines have a
      LATB0 or LATB1 = 0 in the initial phase.


   based on http://www.robot-electronics.co.uk/htm/srf08tech.shtml code
 
*/

#ifndef __i2c_soft
#define __i2c_soft

#define SDA_LOW TRISBbits.TRISB0=0
#define SDA_HIGH TRISBbits.TRISB0=1
#define SDA_LAT  LATBbits.LATB0
#define SDA_IN PORTBbits.RB0

#define SCL_LOW TRISBbits.TRISB1=0
#define SCL_HIGH TRISBbits.TRISB1=1
#define SCL_LAT  LATBbits.LATB1
#define SCL_IN PORTBbits.RB1

void I2C_Delay(void)
{
 delay_us(1);
}

void I2C_Delay2(void)
{
 delay_us(2);
}

void I2C_Delay3(void)
{
 delay_us(3);
}


void InitI2C(void)
{
// put both lines high impedance
// connections need pull-up to VCC

 SDA_LAT=0;
 SCL_LAT=0;

 SDA_HIGH; // tris at 1 keeps it high level
 SCL_HIGH; // tris at 1 keeps it high level

}

void StartI2C(void)
{
   SDA_LAT=0;
   SCL_LAT=0;
   I2C_Delay2();
   SDA_HIGH;
   I2C_Delay();
   SCL_HIGH;
    I2C_Delay2();
    SDA_LOW;
    I2C_Delay();
    SCL_LOW;
    I2C_Delay2();
    return;
 }


void StopI2C(void)
{
    I2C_Delay2();
    SDA_LOW;
    I2C_Delay();
    SCL_HIGH;
    I2C_Delay();
    SDA_HIGH;
    I2C_Delay2();
    return;
 }

// Send a ACK
void sAckI2C( void )
{
    SDA_LOW;
    I2C_Delay();
    SCL_HIGH;
    I2C_Delay2();
    SCL_LOW; // Cmd executin lasts 1usec so clk 100KHz
    I2C_Delay2();
    SDA_HIGH;
}

// Send a NACK
void sNackI2C( void )
{
    SDA_HIGH;
    I2C_Delay2();
    SCL_HIGH;
    I2C_Delay();
    SCL_LOW;
    I2C_Delay2();
}


u8 WriteI2C(u8 senddata)
{
    u8 i;
    u8 ack=1;

    for (i=0; i<8; i++)
    {
        if ( senddata & 0x80) SDA_HIGH;        // MSB first -> LSB last
        else SDA_LOW;

        SCL_HIGH;
        I2C_Delay();

        while(!SCL_IN); // clock streching

        SCL_LOW;
        senddata = senddata << 1;
        I2C_Delay();
    }
    SDA_HIGH;
    I2C_Delay2();
    SCL_HIGH;
    if(SDA_IN==0)ack=0;
    I2C_Delay();
    SCL_LOW;
   I2C_Delay();
   SCL_LAT=0;
    return(ack);
}


u8 ReadI2C(u8 ack)
{
    u8 i, res;
    SDA_HIGH;   // we make sure SDA is an input.
    res = 0;
    for (i=0;i<8;i++)     // each bit at a time, MSB first
    {
      SCL_HIGH;
        I2C_Delay();
      res <<= 1;

        while(!SCL_IN); // wait for stretched scl to get high

        if (SDA_IN) res|=1;
        SCL_LOW;
        I2C_Delay();
    }
//    if(ack) sAckI2C();
   if(ack)SDA_LOW;
    else SDA_HIGH;
    SCL_HIGH;
    I2C_Delay();;
    SCL_LOW;
    SDA_HIGH; // make sure we release the SDA line after ack/nack.
    I2C_Delay();
    SCL_LAT=0;
    return(res);
 }


u8 i2c_rdy(u8 address)
{
   u8 ack;
   StartI2C();            // If the write command is acknowledged,
   ack=WriteI2C(address);  // then the device is ready.
   StopI2C();
   return !ack;
}


u8 i2c_read_byte(u8 sensor,u8 address) 
{
   u8 data;

   StartI2C();
   WriteI2C((sensor|(u8)(address>>7))&0xfe);
   WriteI2C(address);
   StartI2C();
   WriteI2C((sensor|(u8)(address>>7))|1);
   data=ReadI2C(0);
   StopI2C();
   return(data);
}

u16 i2c_read_word(u8 sensor,u8 address) 
{
   u16 data;

   StartI2C();
   WriteI2C((sensor|(u8)(address>>7))&0xfe);
   WriteI2C(address);
   StartI2C();
   WriteI2C((sensor|(u8)(address>>7))|1);
   data=ReadI2C(1);
   data = data<<8;
   data+= ReadI2C(0);              // Read low-byte  , ack false
   StopI2C();
   return(data);
}


void i2c_write_byte(u8 sensor,u8 address, u8 data) {
   //while(!i2c_rdy(sensor) );
   StartI2C();
   WriteI2C((sensor|(u8)(address>>7))&0xfe);
   WriteI2C(address);
   WriteI2C(data);
   StopI2C();
}

///////////////////////////////// from library end

#endif
