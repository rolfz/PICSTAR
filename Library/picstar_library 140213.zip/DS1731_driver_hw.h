/*
    Title:  SD1731 driver for Maxim temperature sensor
	Purpose: test microchip i2c hardware library
	by: Rolf Ziegler
	Date: July 2010
  
	Input: RB0+RB1 of pic 18f4550
	Oupout: Subroutine returning 1 word with temperature of chip
			or temperature in 1/100 deg.
*/


#define SENSOR_ADDRESS 0x9E

#include <i2c.h>
#include <delays.h>

#ifndef SDA_IN
	#define  SDA_IN     TRISBbits.TRISB0 = 1; // define macro for data pin output
	#define  SCL_IN     TRISBbits.TRISB1 = 1; // define macro for data pin input
#endif

void delayi2c(void)
{  //delay between i2c writes
 //Delay10TCYx(25); //delays 250 clock cycles = 50us delay at 20MHz clock
 Delay10TCYx(50); //delays 500 clock cycles = 41us delay at 48MHz clock
} 
void temp_config(u8 data) {

   StartI2C();
   delayi2c();
   WriteI2C(SENSOR_ADDRESS);
   delayi2c();
   WriteI2C(0xac);
   delayi2c();
   WriteI2C(data);
   delayi2c();
   StopI2C();
}


void DS1731_init(void) {

   SDA_IN;
   SCL_IN;

   OpenI2C(MASTER,SLEW_OFF);
   SSPSTAT=0x80;
   SSPADD = 120; 

   delayi2c();
   StartI2C();
   delayi2c();
   WriteI2C(SENSOR_ADDRESS);
   delayi2c();
   WriteI2C(0x51);
   delayi2c();
   StopI2C();
   temp_config(0xc);

}
   

u8 ds1731_rdy(void) 
{
   u8 ack;
   LedR=0;
   StartI2C();            // If the write command is acknowledged,
   ack = WriteI2C(SENSOR_ADDRESS);  // then the device is ready.
   StopI2C();
   return !ack;
   LedR=1;
}

void ds1731_write_byte(u8 address, u8 data) 
{
//   while(!ds1731_rdy());
   StartI2C();
   IdleI2C();
   WriteI2C(SENSOR_ADDRESS);
   IdleI2C();
   WriteI2C(address);
   IdleI2C();
   WriteI2C(data);
   IdleI2C();
   StopI2C();
}


u8 ds1731_read_byte(u8 address) 
{
   u8 data;

   StartI2C();
   IdleI2C();
   WriteI2C(SENSOR_ADDRESS);
   IdleI2C();
   WriteI2C(address);
   IdleI2C();
   RestartI2C();
   IdleI2C();
   WriteI2C(SENSOR_ADDRESS+1);
   IdleI2C();
   data=ReadI2C();
   IdleI2C();
   StopI2C();
   return(data);
}


u16 ds1731_read_word(u8 address)
{
   u8  i;
   u16 data;
   StartI2C();
   delayi2c();
   WriteI2C(SENSOR_ADDRESS);
   delayi2c();
   WriteI2C(address);
   delayi2c();
   RestartI2C();
   delayi2c();
   WriteI2C(SENSOR_ADDRESS+1);
   delayi2c();
   data = ReadI2C();
   AckI2C();
   data =data<<8;
   delayi2c();
   data+= ReadI2C();
   delayi2c();
   NotAckI2C();
   delayi2c();
   StopI2C();
   return(data);
}


u16 ds1731_read_temp(void)
{
	u16 data,temp;

	data=ds1731_read_word(0xAA);

    temp=(temp>>8)*100; 
	temp=temp+((data <<8 )/655);

}
////////////////////// end of driver file /////////////////////////////////////
