/*
   Title:    Pushbutton routines for Picstar
   Purpose:  Provide various ways to check the push-button
   File name: picstar_pushbutton.h
   Version: 1.0

   Description:

   by: Rolf Ziegler
   date: Feb.2010
*/


// simple version, 
// we will count how many time pressed with limit of 1.6sec.
// duration of push are lost.
// timeout on release not implemented
// button variable to be 1 or 2.

// let's define cnton and cntoff as global in order for the main code to be able to read this values.
u8 cnton, cntoff;

u8 get_pushb(u8 button)
{
	u8 cntpush=0;
new_push:
	cnton=0; //  duration pressed
	cntoff=0; // duration released

	if(button==BUTTON1) // test RB6 P1
	{
	Dir_PushB1=1;
	while(PushB1==1)delay_ms(20); // routine will block if not pressed !	
	
	while(!PushB1){
					delay_ms(20);
					cnton++;
					bit_clear(cnton,7);
			        }
	cntpush++;
	Dir_PushB1=0;
	}
	else	// will be BUTTON2
	{
	Dir_PushB2=1;
	while(PushB2==1)delay_ms(20); // routine will block if not pressed !	
	while(!PushB2){
					delay_ms(20);
					cnton++;
					bit_clear(cnton,7);
			    	}
	cntpush++;
	Dir_PushB2=0;
	}


// now we check if an other push comes
	if(button==BUTTON1) // test RB6 P1
	{
	Dir_PushB1=1;
	while(cntoff<0x80)
					{
					delay_ms(10);
					if(!PushB1)	goto new_push;
					cntoff++;
					}
	Dir_PushB1=0;
	}
	else	// will be BUTTON2
	{
	Dir_PushB2=1;
	while(cntoff<0x80)
					{
					delay_ms(10);
					if(!PushB1)	goto new_push;
					cntoff++;
					}
	Dir_PushB2=0;
	}

	return(cntpush);
}
