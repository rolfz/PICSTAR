/*
	Name:  Encoder driver
	Purpose: Routine will keep care of the motor position
		     Encoder_Cnt1 and Encoder_Cnt2 will keep the position
			 Routine has to be called every xxx to make sure we keep track
			 
	By: Rolf Ziegler Based on Didel Starlet CALM code.
					 & LAMI-EPFL Programming the PIC document  OCt 2003
	Date: May 2010

*/

// global variables
volatile	u8 OldPort;
extern s16 Encoder1Cnt;
extern s16 Encoder2Cnt;

s8 CSpeedM1, CSpeedM2;
s8 ESpeedM1,ESpeedM2;

// Moteur A, Encodeur sur C0+C1
	#define MaskB2 0x30 
// Moteur B, Encodeur sur B4+B5
	#define MaskC1 0x03

// we will combine both encoder to save some space and time


//#define DEBUG

void init_encoder(void)
{

		TRISB|=MaskB2; // set RB4 + RB5 as input
		TRISC|=MaskC1; // set RC0 + RC1 as input

		// let's initalize OldPort
		// we read the status of both ports at initialisation
		OldPort=(PORTB & MaskB2) | (PORTC & MaskC1);
}

/* 
	ENCODER routine will identify rotation and increment/decrement a counter for each wheel
	Based on Sommer code from Logitech

	- 1st we copy both encoder into TmpEnco 
	- 2nd we modify OldPort to cross the bit 1-2 get 2-1
	- 3rd we xor both values
	- 4rd we save the TmpEnco into OldPort for next iteration
	- 5th we check the xor result for each encoder, dep on 01 or 10 we increment or decrement
		we ignore if the xor result is 11 or 00 which means no change from last iteration

	For Picstar, the encoder is on C0-C1 and B4-B5 combining it gives us 00ab00cd
	ab is the encoder of motor 1 cd is encoder for motor 2.

	// counter variables are Encoder1Cnt Encoder2Cnt
	
*/
void StepEncoder(void)
{
	u8 Temp;
	

#ifdef DEBUG
	if(PORTBbits.RB4)PORTCbits.RC6=1;
	else PORTCbits.RC6=0;
	if(PORTBbits.RB5)PORTCbits.RC7=1;
	else PORTCbits.RC7=0;
#endif

// let's swap the bits of OldPort and store it in Temp
	Temp=(OldPort>>1)& 0x11;
	Temp|=(OldPort<<1) & 0x22;

// let's read in the new port value
	OldPort=((PORTB & MaskB2)|(PORTC & MaskC1));
// let's xor both values, result in Temp
	Temp^=OldPort;

	if((Temp & MaskC1)==0x01) {Encoder1Cnt++;
							   CSpeedM1++;
							  }
	if((Temp & MaskC1)==0x02) {Encoder1Cnt--;
							   CSpeedM1--;
							  }						  

	if((Temp & MaskB2)==0x10) {Encoder2Cnt++;
							   CSpeedM2++;
							  }
	if((Temp & MaskB2)==0x20) {Encoder2Cnt--;
							   CSpeedM2--;
							   }						  
	// if the result per motor is 00 or 11, we will not change the value.
} // end StepEncoder

// update speed calculated by encoder
// ESpeedM1 and ESpeedM2 are effective speed to be used by application
void EncoSpeed(void)
{
	ESpeedM1=CSpeedM1;
	CSpeedM1=0;
	ESpeedM2=CSpeedM2;
	CSpeedM2=0;
}
