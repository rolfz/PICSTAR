/*
   Title:    Ultrasonic driver
   Purpose:  SRF08 ultrasonic sensor driver for C18 compiler
   File name: SRF08_ultrasonic_driver.h
   Version: 1.0

   by: Rolf Ziegler
   date: April.2010

   description:
		Subroutines to write to command register of sensor and read one byte or word from the sensor
		This allows to setup the sensor and ready in the 2 formats from is.
		Commande registers and echo registers are in the #defined lines of the driver
		Not all features of the ultrasonic sensor are covered with this driver.

   based on http://www.robot-electronics.co.uk/htm/srf08tech.shtml code
 
*/
#ifndef __SRF08_DRIVER
#define __SRF08_DRIVER
// allows to the sensor to provide the 


#define RANGE_INCH 0x50
#define RANGE_CM 0x51
#define RANGE_MS 0x52

#define COMMAND 0x0
#define MAX_GAIN 0x01
#define RANGE_REG 0x02

// memory lecations
#define SOFT_REV 0x00   // read software version of the sensor
#define LIGHT_SENS 0x01 // read the light detector status

#define ECHO1_High 0x02 // 1st echo sensor
#define ECHO1_Low  0x03   

#define SRF_ADDR 0xE0  // sensor address

void SRF08_init(void)
{
	InitI2C();
}

void SRF08_Write_Byte(u8 cmdreg, u8 i2cdata)
{
	i2c_write_byte(SRF_ADDR,cmdreg,i2cdata);
}//~

/*
    Routine reads 2x 8 bit values and combines them to 16 bit distance
*/
u16 SRF08_Read_Word(u8 reg) {

  return(i2c_read_word(SRF_ADDR,reg) );

}//~


u8 SRF08_Read_Byte(u8 reg){

  return i2c_read_byte(SRF_ADDR,reg);
}
#endif

