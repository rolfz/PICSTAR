


#ifndef __XLCD_H
#include <xlcd.h>   // fonctions de gestion du LCD
#endif
#include <delays.h>


#define TRIS_LCD_BACKLIGHT TRISDbits.TRISD3
#define LCD_BACKLIGHT PORTDbits.RD3


// chaine d'espace pour effacer le LCD
rom const unsigned char vide[]="                ";

// positionne le curseur en x-y (0<x<15 et 0<y<1
void lcd_gotoxy(unsigned char x, unsigned char y)
{
if (y) SetDDRamAddr(0x40+x);
 else SetDDRamAddr(x);
}

// efface l'afficheur
void lcd_delete(void)
{   lcd_gotoxy(0,0);   // positionne le curseur en x,y
   putrsXLCD((const rom char *)vide);
   lcd_gotoxy(0,1);
   putrsXLCD((const rom  char *)vide);
}

void putchar(char data)
{
   WriteDataXLCD(data);
}

// dirige user_putc vers l'afficheur LCD du PD2+
int _user_putc (char c)
{
   putcXLCD(c);
}

// xlcd initalize the display in strange way. this should fix it.

#define SHIFT_CUR_OFF 0b00010000
void lcd_init(void)
{

       OpenXLCD( FOUR_BIT & LINES_5X7 ); 

        // Turn the display on then off
        while(BusyXLCD());              // Wait if LCD busy
        WriteCmdXLCD(DON&CURSOR_OFF&BLINK_OFF);           // Display ON/Blink OFF/Cursor OFF

        // Clear display
        while(BusyXLCD());              // Wait if LCD busy
        WriteCmdXLCD(0x01);             // Clear display

        while(BusyXLCD());              // Wait if LCD busy
        WriteCmdXLCD(SHIFT_CUR_OFF);   // Entry Mode // was left

        TRIS_LCD_BACKLIGHT=0; // enable Backlight control ine

}

// Temporisation n�cessaires aux composants de la biblioth�que XLCD
void DelayFor18TCY(void) 
{
    Delay1KTCYx(18);

}

void DelayPORXLCD(void)
{
    Delay1KTCYx(30);

}

void DelayXLCD(void)
{
    Delay1KTCYx(40);
}

#define init_lcd lcd_init 