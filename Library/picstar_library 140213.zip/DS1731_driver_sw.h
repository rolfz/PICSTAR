/*
    Title:  SD1731 driver for Maxim temperature sensor
	Purpose: test microchip i2c hardware library
	by: Rolf Ziegler
	Date: July 2010
  
	Input: RB0+RB1 of pic 18f4550
	Oupout: Subroutine returning 1 word with temperature of chip
			or temperature in 1/100 deg.
*/


#ifndef SENSOR_ADDRESS
	#define SENSOR_ADDRESS 0x9E
#endif

#include "..\shared\sw_i2c_driver.h"
#include <delays.h>

void delayi2c(void)
{  //delay between i2c writes
 Delay10TCY(); //delays 250 clock cycles = 50us delay at 20MHz clock
 Delay10TCY(); //delays 250 clock cycles = 50us delay at 20MHz clock
 Delay10TCY(); //delays 250 clock cycles = 50us delay at 20MHz clock
} 

u8 ds1731_rdy(void) 
{
   u8 ack;
   swStartI2C();            // If the write command is acknowledged,
   ack = swWriteI2C(SENSOR_ADDRESS);  // then the device is ready.
   swWriteI2C(SENSOR_ADDRESS);  // then the device is ready.
   swStopI2C();
   return !ack;
}


void write_config(u8 data) {

   while(ds1731_rdy());
   swStartI2C();
   delayi2c();
   swWriteI2C(SENSOR_ADDRESS);
   delayi2c();
   swWriteI2C(0xac);
   delayi2c();
   swWriteI2C(data);
   delayi2c();
   swStopI2C();
}

void DS1731_init(void) {

   swInitI2C();

   delayi2c();
   swStartI2C();
   delayi2c();
   swWriteI2C(SENSOR_ADDRESS);
   delayi2c();
   swWriteI2C(0x51);  // Start convert
   delayi2c();
   swStopI2C();

   write_config(0xc); // 750ms conversion Contineus conversion

}
 

u8 i2c_ready(void)
{
   u8 ack;   
   swStartI2C();
   ack=swWriteI2C(SENSOR_ADDRESS);
   swStopI2C();
   return !ack;
}

  
u16 ds1731_read_word(u8 address)
{
   u16 data=0;
   swStartI2C();
   delayi2c();
   swWriteI2C(SENSOR_ADDRESS); // ie 0x9E
   delayi2c();
   swWriteI2C(address);	// write command
   delayi2c();
   swRestartI2C();
   delayi2c();
   swWriteI2C(SENSOR_ADDRESS+1); // ie 0x9F
   delayi2c();
   data = swReadI2C(1);
   data =data<<8;
   delayi2c();
   data+= swReadI2C(0);
   delayi2c();
   swStopI2C();
   return(data);
}


// return tempearture in 1/100 degrees resolution
s16 ds1731_read_temp(void)
{
	s16 datah,datal;
	s16 Tdec=0;

	swStartI2C();
    swWriteI2C(SENSOR_ADDRESS);
    swWriteI2C(0xaa);
    swRestartI2C();
    swWriteI2C(SENSOR_ADDRESS+1);
    datah=swReadI2C(1);
    datal=swReadI2C(0);
    swStopI2C();
                 
    if(datah>=0x80)
		{
		datah-=256;
		if(datal==0x80)Tdec=-5;
   		}
	else 	if(datal==0x80)Tdec=5;
   	
	Tdec+=datah*10;
   	
	return Tdec;
}
////////////////////// end of driver file /////////////////////////////////////
