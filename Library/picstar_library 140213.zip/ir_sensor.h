/*
   Name:    ir_sensor.h       
   Title:   PICSTAR IR PROXIMITY detector
   Purpose: IR-Sensor will detect table limits and horizontal obstacles.
			tested with PICSTAR Hardware version 1.1 + Didel IR sensor board.

   by: Rolf Ziegler
   date: June 2010

   INPUT: Port on which IR sensors are connected + 1 IR-light line
   OUPUT: array of unsigned int8 (u8) ir_sensor[6], one value for each sensor

   Description:	IR-Sensor will detect table limits and obstacles.

   Routine is made for IR board from DIDEL.CH including 3 sensors on one board
   2 horizontal and one vertical sensors. Sensor is made of 1 IR LED, all 3 driven over FET.
   3 sensor transistors are in parallel to a capacitor. The current routine is made for 6 sensors 
   connected to PORTA + 1 LINE FOR THE IR-led connected to RC7.

	Process to read: 1. we initalize the port on which the sensors are connected to.
					 2. each 100ms, we turn the port to output with all lined high level
						this charges the capacitors (100nF).
						We set a flag that initiates the mesure routine to run all 500us
						We clear a counter that will be used to mesure the distances.
					 3. Each 500us, called by interrupt,
						We wait 1ms (2 turns) to charge the caps, then we turn the PORT to intput
						now we check each individual input and copy the coutner to a register if high level.
						When all lines are low-level we stop the process.
						Also we turn the 500us routine off if we reach 20ms (40 iterations).
						
						Also we copy all distances during 100ms routine to a buffer register
						so the variables are not changed during mesurement.

	Mesurements:  Without any obstacle, we reach the limit means value = 40 (20ms)

				  Vertical: sensor mesured 3-4, means 1.5-2ms when on table
						   at table edge, value increases to 25-30 depending on the table edge.
				  		   On a black line (Tesa Tape), the value goes up to 9-10.

				  Horizontal: Due to table reflection the value without obstacles is not 40, we mesured 22-30.
								white obstacle at 30cm  22
												  20cm  17
												  15cm  15
												  10cm  12
												  5cm    6
												  1cm    2 (equivalent to the charging time of the caps which is 1ms)

				!! Values are not absolute as depending on ambiant light and surfaces reflection.
						   
					
	Timing: critical as running in interrupt procees:

	current code in C18
			IR_Sensor_100ms(void) takes 12.5us
			IR_Sensor_500us(void) takes 15 us

	maybe ported to assembler for optimisaiton

*/

#ifndef __IR_SENSOR
#define __IR_SENSOR

#define IR_PORT PORTA
#define IR_LAT LATA

#define TRIS_IR_PORT TRISA

#define IR_LIGHT	PORTCbits.RC7
#define TRIS_IRLIGHT TRISCbits.TRISC7

u16 ir_counter;
u8  ir_state[6];
u8  mesure_sensors;		// if 1 routine will count IR sensors status
extern u8  ir_sensor[6];

u8 test;

void Init_IR_Sensor(void)
{
	u8 i;
	ADCON1=0x0f; // switch off ADC

	// IR SENSOR PORT
	IR_LAT=0xff; // we prepare the port high level
	TRIS_IR_PORT=0xff; // we keep the port as input until we need it.

	// IR LIGHT
	IR_LIGHT=0; // prepare IR off
	TRIS_IRLIGHT=0; // set IR LED IO as output

	// clear the sensor variables
    for(i=0;i<6;i++) ir_state[i]=0;

	TRIS_INT_TEST=0;

}


// ir sensor trigger, initalizes the mesuring process
// charges the capacitors on sensor
void IR_Sensor_100ms(u8 light)
{	
	u8 i;
	// we switch on the IR LED
	IR_LIGHT=light; 
	// we copy the old values to avoid read during write errors
    for(i=0;i<6;i++) ir_sensor[i]=ir_state[i];
	// we initalize the cycle
	ir_counter=0;
	// we switch the PORTA to output
	TRIS_IR_PORT=0;	
	// we start reading the sensor every half 1 ms.
	mesure_sensors=1;

}

// this routine will mesure the time until the IR level is under switch level
// it will only run every 20ms and until all IR-bits are at low level.
//
// the sensor status of each sensor will be stored in ir_state array.
//
void IR_Sensor_500us(void)
{
	u8 i;
	if(mesure_sensors)
	{
	if(ir_counter>1) // we charge the cap for 10 cycles, then we turn intro reading it
         {
  		 TRIS_IR_PORT=0xff;	// make sure we are in input mode
		 for(i=0;i<6;i++) if(bit_test(IR_PORT,i)) ir_state[i]=ir_counter;
		 }
	// if all io lines are low we stop mesuring and swich off the IR light
	if(IR_PORT&0x3f==0){
			mesure_sensors=0;
			IR_LIGHT=0;
	              }				
	ir_counter++;
	}
	// we stop if the counter reached half the range
	if(ir_counter==40){mesure_sensors=0;
					   IR_LIGHT=0;
				       }				   
}

#endif