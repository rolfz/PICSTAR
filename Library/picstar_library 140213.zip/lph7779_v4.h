////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*

Graphic LCD Nokia 3310 (LPH7779) header file
CCS compiler
dsrex

by Rolf Ziegler 2006

*/
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


#define Nokia_Port   LATD
#define Nokia_Tris   TRISD
#define Nokia_sclk   LATDbits.LATD4
#define Nokia_sda    LATDbits.LATD3    // goes to SDI of LCD
#define Nokia_dc     LATDbits.LATD2
#define Nokia_cs     LATDbits.LATD1    // active low
#define Nokia_res    LATDbits.LATD0    // reset, active low

#define Nokia_BL1    LATDbits.LATD6
#define Nokia_BL2    LATDbits.LATD7

//
u8  char_row,charsel,charpos,chardata; 		// for Nokia_3310 lcd
u16 ddram;
u8  plot_value;
u32 plot_value32;
u32 plot_umsb,plot_lmsb,plot_ulsb,plot_llsb;
